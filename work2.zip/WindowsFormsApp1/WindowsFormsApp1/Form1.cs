﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int[] ans = new int[10000];
        String[] que = new String[10000];
        int l = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int i, j;
            int[] temp =new int[5];
            Random rn = new Random();
            char[] Symbol = { '+', '-', 'X', '/', '=', '(', ')', '\0' };
            int num = int.Parse(this.textBox1.Text);
                for (i = 1; i <= num; i++)
                {
                flg1: temp[0] = rn.Next(0,100);
                    temp[1] = rn.Next(0, 100);
                    temp[2] = rn.Next(0, 100);
                    temp[3] = rn.Next(0, 4);
                    temp[4] = rn.Next(0, 4);
                    if (temp[3] == 0 || temp[3] == 1)
                    {
                        if (temp[3] == 1)
                        {
                            if (temp[0] < temp[1])
                            {
                                goto flg1;
                            }
                            ans[i] = Calculation(temp[3], temp[0], temp[1]);
                            if (ans[i] > 100)
                            {
                                goto flg1;
                            }
                        }
                        if (temp[3] == 0)
                        {
                            ans[i] = Calculation(temp[3], temp[0], temp[1]);
                            if (ans[i] > 100)
                            {
                                goto flg1;
                            }
                        }
                        if (temp[4] == 0 || temp[4] == 1)
                        {
                            if (temp[4] == 1)
                            {
                                j = 1;
                                while (ans[i] < temp[2])
                                {
                                    temp[2] = rn.Next(0, 100);
                                    j++;
                                    if (j == 20)
                                    {
                                        goto flg1;
                                    }
                                }
                                ans[i] = Calculation(temp[4], ans[i], temp[2]);
                                if (ans[i] > 100)
                                {
                                    goto flg1;
                                }
                                else
                                {
                                    String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                    textBox2.AppendText(c + System.Environment.NewLine);
                                que[l] = c + "\n";
                                l++;
                                continue;
                                }
                            }
                            if (temp[4] == 0)
                            {
                                ans[i] = Calculation(temp[4], ans[i], temp[2]);
                                if (ans[i] > 100)
                                {
                                    goto flg1;
                                }
                                else
                                {
                                    String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                textBox2.AppendText(c + System.Environment.NewLine);
                                que[l] = c + "\n";
                                l++;
                                continue;
                                }
                            }

                        }
                        else
                        {
                            if (temp[4] == 2)
                            {
                                ans[i] = Calculation(temp[4], ans[i], temp[2]);
                                if (ans[i] > 100)
                                {
                                    goto flg1;
                                }
                                else
                                {
                                    String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                textBox2.AppendText(c + System.Environment.NewLine);
                                que[l] = c+"\n";
                                l++;
                                continue;
                                }
                            }
                            if (temp[4] == 3)
                            {
                                if (temp[2] != 0 && (ans[i] % temp[2] == 0))
                                {
                                    ans[i] = Calculation(temp[4], ans[i], temp[2]);
                                    String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                textBox2.AppendText(c + System.Environment.NewLine);
                                que[l] = c + "\n";
                                l++;
                                continue;
                                }
                                else
                                {
                                    goto flg1;
                                }
                            }

                        }
                    }
                    if (temp[3] == 2 || temp[3] == 3)
                    {
                        if (temp[3] == 2)
                        {
                            ans[i] = Calculation(temp[3], temp[0], temp[1]);
                            if (ans[i] > 100)
                            {
                                goto flg1;
                            }
                        }
                        if (temp[3] == 3)
                        {
                            if (temp[1] != 0 && (temp[0] % temp[1] == 0))
                            {
                                ans[i] = Calculation(temp[3], temp[0], temp[1]);
                                if (ans[i] > 100)
                                {
                                    goto flg1;
                                }
                            }
                            else
                            {
                                goto flg1;
                            }
                        }
                        if (temp[4] == 0 || temp[4] == 1)
                        {
                            if (temp[4] == 0)
                            {
                                ans[i] = Calculation(temp[4], ans[i], temp[2]);
                                if (ans[i] > 100)
                                {
                                    goto flg1;
                                }
                                else
                                {
                                    if (temp[3] == 2)
                                    {
                                        String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                    textBox2.AppendText(c + System.Environment.NewLine);
                                    que[l] = c + "\n";
                                    l++;
                                    continue;
                                    }

                                    else
                                    {
                                        String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                    textBox2.AppendText(c + System.Environment.NewLine);
                                    que[l] = c + "\n";
                                    l++;
                                    continue;
                                    }
                                }
                            }
                            if (temp[4] == 1)
                            {
                                j = 1;
                                while (ans[i] < temp[2])
                                {
                                    temp[2] = rn.Next(0, 100);
                                    j++;
                                    if (j == 20)
                                    {
                                        goto flg1;
                                    }
                                }
                                ans[i] = Calculation(temp[4], ans[i], temp[2]);
                                if (ans[i] > 100)
                                {
                                    goto flg1;
                                }
                                else
                                {
                                    if (temp[3] == 2)
                                    {
                                        String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                    textBox2.AppendText(c + System.Environment.NewLine);
                                    que[l] = c + "\n";
                                    l++;
                                    continue;
                                    }
                                    else
                                    {
                                        String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                    textBox2.AppendText(c + System.Environment.NewLine);
                                    que[l] = c + "\n";
                                    l++;
                                    continue;
                                    }
                                }
                            }

                        }
                        if (temp[4] == 2)
                        {
                            ans[i] = Calculation(temp[4], ans[i], temp[2]);
                            if (ans[i] > 100)
                            {
                                goto flg1;
                            }
                            else
                            {
                                if (temp[3] == 2)
                                {
                                    String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                textBox2.AppendText(c + System.Environment.NewLine);
                                que[l] = c + "\n";
                                l++;
                                continue;
                                }

                                else
                                {
                                    String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                textBox2.AppendText(c + System.Environment.NewLine);
                                que[l] = c + "\n";
                                l++;
                                continue;
                                }

                            }
                        }
                        if (temp[4] == 3)
                        {
                            if (temp[2] != 0 && (ans[i] % temp[2] == 0))
                            {
                                ans[i] = Calculation(temp[4], ans[i], temp[2]);
                                if (ans[i] > 100)
                                {
                                    goto flg1;
                                }
                                else
                                {
                                    if (temp[3] == 2)
                                    {
                                        String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                    textBox2.AppendText(c + System.Environment.NewLine);
                                    que[l] = c + "\n";
                                    l++;
                                    continue;
                                    }

                                    else
                                    {
                                        String c = Convert.ToString(temp[0]) + Symbol[temp[3]] + Convert.ToString(temp[1]) + Symbol[temp[4]] + Convert.ToString(temp[2]) + Symbol[4];
                                    textBox2.AppendText(c + System.Environment.NewLine);
                                    que[l] = c + "\n";
                                    l++;
                                    continue;
                                    }

                                }
                            }
                            else
                            {
                                goto flg1;
                            }
                        }

                    }
                }
        }
        public int Calculation(int k, int a, int b)
        {
            if (k == 0)
                return a + b;
            if (k == 1)
            {
                return a - b;
            }

            if (k == 2)
                return a * b;
            if (k == 3)
            {
                if (b != 0)
                    return a / b;
            }
            return 0;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter(@"E:\\123.txt", true, Encoding.ASCII);
            for (int i = 1; i <= l; i++)
            {
                if (que[i] != null)
                {
                    sw.Write(que[i]+ Environment.NewLine);
                }
            }
            sw.Flush();
            sw.Close();
            MessageBox.Show("导入成功");
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            ans = new int[10000];
            que = new string[10000];
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            int n = int.Parse(this.textBox1.Text);
            for (int i = 1; i <= n ; i++)
            {
                textBox3.AppendText(Convert.ToString(ans[i]) + System.Environment.NewLine);
            }
        }
    }
}
